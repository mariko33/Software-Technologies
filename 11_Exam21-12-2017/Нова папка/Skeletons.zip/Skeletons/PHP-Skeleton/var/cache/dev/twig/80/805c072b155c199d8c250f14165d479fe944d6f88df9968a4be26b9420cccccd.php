<?php

/* report/details.html.twig */
class __TwigTemplate_7c290bcb47ec784747a4909d33c06ca108dd3d492ba346a19c1f4f7adebeee67 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "report/details.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c6f6bccc2c6e6a6eb80f58c2c61de8a1e919976f0c25f4406ea2386ade26540e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c6f6bccc2c6e6a6eb80f58c2c61de8a1e919976f0c25f4406ea2386ade26540e->enter($__internal_c6f6bccc2c6e6a6eb80f58c2c61de8a1e919976f0c25f4406ea2386ade26540e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "report/details.html.twig"));

        $__internal_f4c7427dbfbec1cfbb70ac793036b0896aed8bdd6203ee81e8dffc1d28415685 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f4c7427dbfbec1cfbb70ac793036b0896aed8bdd6203ee81e8dffc1d28415685->enter($__internal_f4c7427dbfbec1cfbb70ac793036b0896aed8bdd6203ee81e8dffc1d28415685_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "report/details.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c6f6bccc2c6e6a6eb80f58c2c61de8a1e919976f0c25f4406ea2386ade26540e->leave($__internal_c6f6bccc2c6e6a6eb80f58c2c61de8a1e919976f0c25f4406ea2386ade26540e_prof);

        
        $__internal_f4c7427dbfbec1cfbb70ac793036b0896aed8bdd6203ee81e8dffc1d28415685->leave($__internal_f4c7427dbfbec1cfbb70ac793036b0896aed8bdd6203ee81e8dffc1d28415685_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_4ea2d4cc31969252bcd065e9201a137810de6fb211b552da57835401466b8adf = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4ea2d4cc31969252bcd065e9201a137810de6fb211b552da57835401466b8adf->enter($__internal_4ea2d4cc31969252bcd065e9201a137810de6fb211b552da57835401466b8adf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_943026f400f0a08a0b0adc0635970f0d5232035cc1bf1552c66a93b2c387b130 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_943026f400f0a08a0b0adc0635970f0d5232035cc1bf1552c66a93b2c387b130->enter($__internal_943026f400f0a08a0b0adc0635970f0d5232035cc1bf1552c66a93b2c387b130_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "<div class=\"wrapper\">
    <div class=\"report-details\">
        <div class=\"details-header\">
            Report Details
        </div>
        <div class=\"details-status\">
            <div class=\"details-status-label\">Status</div>
            <div class=\"details-status-content\">";
        // line 11
        echo twig_escape_filter($this->env, $this->getAttribute(($context["report"] ?? $this->getContext($context, "report")), "status", array()), "html", null, true);
        echo "</div>
        </div>
        <div class=\"details-message\">
            <div class=\"details-message-label\">Message</div>
            <div class=\"details-message-content\">
                ";
        // line 16
        echo twig_escape_filter($this->env, $this->getAttribute(($context["report"] ?? $this->getContext($context, "report")), "message", array()), "html", null, true);
        echo "
            </div>
        </div>
        <div class=\"details-origin\">
            <div class=\"details-origin-label\">Origin</div>
            <div class=\"details-origin-content\">
                ";
        // line 22
        echo twig_escape_filter($this->env, $this->getAttribute(($context["report"] ?? $this->getContext($context, "report")), "origin", array()), "html", null, true);
        echo "
            </div>
        </div>
    </div>
    <div class=\"details-button-holder\">
        <a type=\"button\" href=\"/\" class=\"back-button\">Back</a>
    </div>
</div>
";
        
        $__internal_943026f400f0a08a0b0adc0635970f0d5232035cc1bf1552c66a93b2c387b130->leave($__internal_943026f400f0a08a0b0adc0635970f0d5232035cc1bf1552c66a93b2c387b130_prof);

        
        $__internal_4ea2d4cc31969252bcd065e9201a137810de6fb211b552da57835401466b8adf->leave($__internal_4ea2d4cc31969252bcd065e9201a137810de6fb211b552da57835401466b8adf_prof);

    }

    public function getTemplateName()
    {
        return "report/details.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  75 => 22,  66 => 16,  58 => 11,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}

{% block main %}
<div class=\"wrapper\">
    <div class=\"report-details\">
        <div class=\"details-header\">
            Report Details
        </div>
        <div class=\"details-status\">
            <div class=\"details-status-label\">Status</div>
            <div class=\"details-status-content\">{{report.status}}</div>
        </div>
        <div class=\"details-message\">
            <div class=\"details-message-label\">Message</div>
            <div class=\"details-message-content\">
                {{report.message}}
            </div>
        </div>
        <div class=\"details-origin\">
            <div class=\"details-origin-label\">Origin</div>
            <div class=\"details-origin-content\">
                {{report.origin}}
            </div>
        </div>
    </div>
    <div class=\"details-button-holder\">
        <a type=\"button\" href=\"/\" class=\"back-button\">Back</a>
    </div>
</div>
{% endblock %}", "report/details.html.twig", "C:\\Users\\Ivo\\Desktop\\Soft-Tech-Exam-21\\Solutions\\PHP Skeleton\\app\\Resources\\views\\report\\details.html.twig");
    }
}
