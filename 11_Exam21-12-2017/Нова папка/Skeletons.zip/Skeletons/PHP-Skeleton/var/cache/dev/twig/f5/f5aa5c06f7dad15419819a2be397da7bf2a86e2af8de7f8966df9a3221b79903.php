<?php

/* report/index.html.twig */
class __TwigTemplate_2c43e0a5c05b4781e8a8095540521bae3bbdb9ed7f47f8b866ba14e13972b98c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "report/index.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0da56f20642e6a59ff4282a3b4bec37b73b4b11a7c1bf9eebbe9d400a50dd63f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0da56f20642e6a59ff4282a3b4bec37b73b4b11a7c1bf9eebbe9d400a50dd63f->enter($__internal_0da56f20642e6a59ff4282a3b4bec37b73b4b11a7c1bf9eebbe9d400a50dd63f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "report/index.html.twig"));

        $__internal_d580ee1f64b24c2c5b3131fa36e46f3f6f4c8dd56f8064ab9af925fd7a709975 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d580ee1f64b24c2c5b3131fa36e46f3f6f4c8dd56f8064ab9af925fd7a709975->enter($__internal_d580ee1f64b24c2c5b3131fa36e46f3f6f4c8dd56f8064ab9af925fd7a709975_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "report/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0da56f20642e6a59ff4282a3b4bec37b73b4b11a7c1bf9eebbe9d400a50dd63f->leave($__internal_0da56f20642e6a59ff4282a3b4bec37b73b4b11a7c1bf9eebbe9d400a50dd63f_prof);

        
        $__internal_d580ee1f64b24c2c5b3131fa36e46f3f6f4c8dd56f8064ab9af925fd7a709975->leave($__internal_d580ee1f64b24c2c5b3131fa36e46f3f6f4c8dd56f8064ab9af925fd7a709975_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_d9dd6c853b4665d8ccc83e03c957c4a92e69fb52364d2b828fb7279feabb6bc7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d9dd6c853b4665d8ccc83e03c957c4a92e69fb52364d2b828fb7279feabb6bc7->enter($__internal_d9dd6c853b4665d8ccc83e03c957c4a92e69fb52364d2b828fb7279feabb6bc7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_a3eeb91bfd25b70bcf1bdabe4291aa8b87a11a7847912b4a2924888a79c4c4f8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a3eeb91bfd25b70bcf1bdabe4291aa8b87a11a7847912b4a2924888a79c4c4f8->enter($__internal_a3eeb91bfd25b70bcf1bdabe4291aa8b87a11a7847912b4a2924888a79c4c4f8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "<div class=\"wrapper\">
    <div class=\"button-holder\">
        <a type=\"button\" href=\"/create\" class=\"log-button\">Log New Report</a>
    </div>
    <div class=\"content\">
        <div class=\"header\">
            <div class=\"message-label\">Message</div>
            <div class=\"actions-label\">Actions</div>
        </div>
        <div class=\"main\">
            ";
        // line 14
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["reports"] ?? $this->getContext($context, "reports")));
        foreach ($context['_seq'] as $context["_key"] => $context["report"]) {
            // line 15
            echo "            <div class=\"report ";
            echo twig_escape_filter($this->env, twig_lower_filter($this->env, $this->getAttribute($context["report"], "status", array())), "html", null, true);
            echo "-report\">
                <div class=\"report-message\">
                    ";
            // line 17
            echo twig_escape_filter($this->env, (((twig_length_filter($this->env, $this->getAttribute($context["report"], "message", array())) > 50)) ? ((twig_slice($this->env, $this->getAttribute($context["report"], "message", array()), 0, 50) . "...")) : ($this->getAttribute($context["report"], "message", array()))), "html", null, true);
            echo "
                </div>
                <div class=\"report-actions\">
                    <a type=\"button\" href=\"";
            // line 20
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("details", array("id" => $this->getAttribute($context["report"], "id", array()))), "html", null, true);
            echo "\" class=\"details-button\">Details</a>
                    <a type=\"button\" href=\"";
            // line 21
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("delete", array("id" => $this->getAttribute($context["report"], "id", array()))), "html", null, true);
            echo "\" class=\"delete-button\">Delete</a>
                </div>
            </div>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['report'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 25
        echo "        </div>
    </div>
</div>
";
        
        $__internal_a3eeb91bfd25b70bcf1bdabe4291aa8b87a11a7847912b4a2924888a79c4c4f8->leave($__internal_a3eeb91bfd25b70bcf1bdabe4291aa8b87a11a7847912b4a2924888a79c4c4f8_prof);

        
        $__internal_d9dd6c853b4665d8ccc83e03c957c4a92e69fb52364d2b828fb7279feabb6bc7->leave($__internal_d9dd6c853b4665d8ccc83e03c957c4a92e69fb52364d2b828fb7279feabb6bc7_prof);

    }

    public function getTemplateName()
    {
        return "report/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  91 => 25,  81 => 21,  77 => 20,  71 => 17,  65 => 15,  61 => 14,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}

{% block main %}
<div class=\"wrapper\">
    <div class=\"button-holder\">
        <a type=\"button\" href=\"/create\" class=\"log-button\">Log New Report</a>
    </div>
    <div class=\"content\">
        <div class=\"header\">
            <div class=\"message-label\">Message</div>
            <div class=\"actions-label\">Actions</div>
        </div>
        <div class=\"main\">
            {% for report in reports %}
            <div class=\"report {{ report.status|lower }}-report\">
                <div class=\"report-message\">
                    {{ report.message|length > 50 ? (report.message|slice(0, 50)) ~ '...' : report.message}}
                </div>
                <div class=\"report-actions\">
                    <a type=\"button\" href=\"{{ path('details', {id: report.id}) }}\" class=\"details-button\">Details</a>
                    <a type=\"button\" href=\"{{ path('delete', {id: report.id}) }}\" class=\"delete-button\">Delete</a>
                </div>
            </div>
            {% endfor %}
        </div>
    </div>
</div>
{% endblock %}", "report/index.html.twig", "C:\\Users\\Ivo\\Desktop\\Soft-Tech-Exam-21\\Solutions\\PHP Skeleton\\app\\Resources\\views\\report\\index.html.twig");
    }
}
