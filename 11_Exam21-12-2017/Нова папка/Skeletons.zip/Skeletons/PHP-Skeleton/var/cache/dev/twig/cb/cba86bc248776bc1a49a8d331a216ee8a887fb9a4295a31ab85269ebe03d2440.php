<?php

/* report/create.html.twig */
class __TwigTemplate_50cffc06a55849e0ae03dbc64920540914af986a1718718f0f9422e603a838a9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "report/create.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b33812698b4d46a05fa3e72e11910846e8e8792fccb8910cb51bb89bac44048b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b33812698b4d46a05fa3e72e11910846e8e8792fccb8910cb51bb89bac44048b->enter($__internal_b33812698b4d46a05fa3e72e11910846e8e8792fccb8910cb51bb89bac44048b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "report/create.html.twig"));

        $__internal_6422999d7115dddcc0e0f6c2a5ad5f82658d8a063b964098b84de20beb7126dc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6422999d7115dddcc0e0f6c2a5ad5f82658d8a063b964098b84de20beb7126dc->enter($__internal_6422999d7115dddcc0e0f6c2a5ad5f82658d8a063b964098b84de20beb7126dc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "report/create.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b33812698b4d46a05fa3e72e11910846e8e8792fccb8910cb51bb89bac44048b->leave($__internal_b33812698b4d46a05fa3e72e11910846e8e8792fccb8910cb51bb89bac44048b_prof);

        
        $__internal_6422999d7115dddcc0e0f6c2a5ad5f82658d8a063b964098b84de20beb7126dc->leave($__internal_6422999d7115dddcc0e0f6c2a5ad5f82658d8a063b964098b84de20beb7126dc_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_a421daf8a75855a5173e0c1e6a637f0d74f9a011a13830d0019eeb8812044798 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a421daf8a75855a5173e0c1e6a637f0d74f9a011a13830d0019eeb8812044798->enter($__internal_a421daf8a75855a5173e0c1e6a637f0d74f9a011a13830d0019eeb8812044798_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_b083b8c649a89fcd4c5e156d24566ff332117f2168e5c70ff3b1127caa52fc61 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b083b8c649a89fcd4c5e156d24566ff332117f2168e5c70ff3b1127caa52fc61->enter($__internal_b083b8c649a89fcd4c5e156d24566ff332117f2168e5c70ff3b1127caa52fc61_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "<div class=\"wrapper\">
    <form class=\"report-create\" method=\"post\">
        <div class=\"create-header\">
            Log Report
        </div>
        <div class=\"create-status\">
            <div class=\"create-status-label\">Status</div>
            <div class=\"create-status-content\">
                <input type=\"radio\" id=\"normal-status\" name=\"report[status]\" value=\"Normal\" checked/>
                <label for=\"normal-status\">Normal</label>
                <input type=\"radio\" id=\"warning-status\" name=\"report[status]\" value=\"Warning\" />
                <label for=\"warning-status\">Warning</label>
                <input type=\"radio\" id=\"critical-status\" name=\"report[status]\" value=\"Critical\" />
                <label for=\"critical-status\">Critical</label>
            </div>
        </div>
        <div class=\"create-message\">
            <div class=\"create-message-label\">Message</div>
            <textarea rows=\"3\" class=\"create-message-content\" name=\"report[message]\" required></textarea>
        </div>
        <div class=\"create-origin\">
            <div class=\"create-origin-label\">Origin</div>
            <textarea rows=\"3\" class=\"create-origin-content\" name=\"report[origin]\" required></textarea>
        </div>
        <div class=\"create-button-holder\">
            <button type=\"submit\" class=\"submit-button\">Log Report</button>
            <a type=\"button\" href=\"/\" class=\"back-button\">Back</a>
        </div>

        ";
        // line 33
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "_token", array()), 'row');
        echo "
    </form>
</div>
";
        
        $__internal_b083b8c649a89fcd4c5e156d24566ff332117f2168e5c70ff3b1127caa52fc61->leave($__internal_b083b8c649a89fcd4c5e156d24566ff332117f2168e5c70ff3b1127caa52fc61_prof);

        
        $__internal_a421daf8a75855a5173e0c1e6a637f0d74f9a011a13830d0019eeb8812044798->leave($__internal_a421daf8a75855a5173e0c1e6a637f0d74f9a011a13830d0019eeb8812044798_prof);

    }

    public function getTemplateName()
    {
        return "report/create.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  80 => 33,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}

{% block main %}
<div class=\"wrapper\">
    <form class=\"report-create\" method=\"post\">
        <div class=\"create-header\">
            Log Report
        </div>
        <div class=\"create-status\">
            <div class=\"create-status-label\">Status</div>
            <div class=\"create-status-content\">
                <input type=\"radio\" id=\"normal-status\" name=\"report[status]\" value=\"Normal\" checked/>
                <label for=\"normal-status\">Normal</label>
                <input type=\"radio\" id=\"warning-status\" name=\"report[status]\" value=\"Warning\" />
                <label for=\"warning-status\">Warning</label>
                <input type=\"radio\" id=\"critical-status\" name=\"report[status]\" value=\"Critical\" />
                <label for=\"critical-status\">Critical</label>
            </div>
        </div>
        <div class=\"create-message\">
            <div class=\"create-message-label\">Message</div>
            <textarea rows=\"3\" class=\"create-message-content\" name=\"report[message]\" required></textarea>
        </div>
        <div class=\"create-origin\">
            <div class=\"create-origin-label\">Origin</div>
            <textarea rows=\"3\" class=\"create-origin-content\" name=\"report[origin]\" required></textarea>
        </div>
        <div class=\"create-button-holder\">
            <button type=\"submit\" class=\"submit-button\">Log Report</button>
            <a type=\"button\" href=\"/\" class=\"back-button\">Back</a>
        </div>

        {{ form_row(form._token) }}
    </form>
</div>
{% endblock %}", "report/create.html.twig", "C:\\Users\\Ivo\\Desktop\\Soft-Tech-Exam-21\\Solutions\\PHP Skeleton\\app\\Resources\\views\\report\\create.html.twig");
    }
}
