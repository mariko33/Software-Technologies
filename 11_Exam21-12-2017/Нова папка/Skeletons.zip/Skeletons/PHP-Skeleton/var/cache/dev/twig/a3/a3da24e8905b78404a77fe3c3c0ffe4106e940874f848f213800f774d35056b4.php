<?php

/* base.html.twig */
class __TwigTemplate_93e2499d03c6402ea1e3906495568257ed0120721f7f5badb0e11600e82927c5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body_id' => array($this, 'block_body_id'),
            'body' => array($this, 'block_body'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4e52afb7703d4a8a05fd47e5191346364e22d5c6557bc39cf51de5b0dd6cec80 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4e52afb7703d4a8a05fd47e5191346364e22d5c6557bc39cf51de5b0dd6cec80->enter($__internal_4e52afb7703d4a8a05fd47e5191346364e22d5c6557bc39cf51de5b0dd6cec80_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_a2771fb58235ea09b9e31bc0d20c2bca52851acbc96738a5f1b93e8ebc344138 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a2771fb58235ea09b9e31bc0d20c2bca52851acbc96738a5f1b93e8ebc344138->enter($__internal_a2771fb58235ea09b9e31bc0d20c2bca52851acbc96738a5f1b93e8ebc344138_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 6
        echo "<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <title>";
        // line 10
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
        // line 11
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 17
        echo "    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\"/>
</head>

<body id=\"";
        // line 20
        $this->displayBlock('body_id', $context, $blocks);
        echo "\">
";
        // line 21
        $this->displayBlock('body', $context, $blocks);
        // line 24
        echo "</body>
</html>
";
        
        $__internal_4e52afb7703d4a8a05fd47e5191346364e22d5c6557bc39cf51de5b0dd6cec80->leave($__internal_4e52afb7703d4a8a05fd47e5191346364e22d5c6557bc39cf51de5b0dd6cec80_prof);

        
        $__internal_a2771fb58235ea09b9e31bc0d20c2bca52851acbc96738a5f1b93e8ebc344138->leave($__internal_a2771fb58235ea09b9e31bc0d20c2bca52851acbc96738a5f1b93e8ebc344138_prof);

    }

    // line 10
    public function block_title($context, array $blocks = array())
    {
        $__internal_53591f45ce5736f9d09c1cadb0c1808f4beb2370ffc1f28b10207ac255d7a3f8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_53591f45ce5736f9d09c1cadb0c1808f4beb2370ffc1f28b10207ac255d7a3f8->enter($__internal_53591f45ce5736f9d09c1cadb0c1808f4beb2370ffc1f28b10207ac255d7a3f8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_0a0fc51262844c7c145833020f997a2b7323bbb57b843455e8bfcb672e8ce29b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0a0fc51262844c7c145833020f997a2b7323bbb57b843455e8bfcb672e8ce29b->enter($__internal_0a0fc51262844c7c145833020f997a2b7323bbb57b843455e8bfcb672e8ce29b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Log Noziroh";
        
        $__internal_0a0fc51262844c7c145833020f997a2b7323bbb57b843455e8bfcb672e8ce29b->leave($__internal_0a0fc51262844c7c145833020f997a2b7323bbb57b843455e8bfcb672e8ce29b_prof);

        
        $__internal_53591f45ce5736f9d09c1cadb0c1808f4beb2370ffc1f28b10207ac255d7a3f8->leave($__internal_53591f45ce5736f9d09c1cadb0c1808f4beb2370ffc1f28b10207ac255d7a3f8_prof);

    }

    // line 11
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_e1da9bf180a41e6ef2cce3aa4894564a2e90ceebcc37aab0d18d3839d61f93f3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e1da9bf180a41e6ef2cce3aa4894564a2e90ceebcc37aab0d18d3839d61f93f3->enter($__internal_e1da9bf180a41e6ef2cce3aa4894564a2e90ceebcc37aab0d18d3839d61f93f3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_cc5d3e5676fe7d7f8d709cdc9bedbc84226ad2078736ea33fc28781cbfdcf5e2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cc5d3e5676fe7d7f8d709cdc9bedbc84226ad2078736ea33fc28781cbfdcf5e2->enter($__internal_cc5d3e5676fe7d7f8d709cdc9bedbc84226ad2078736ea33fc28781cbfdcf5e2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 12
        echo "        <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/reset.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/style.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/details-style.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/create-style.css"), "html", null, true);
        echo "\">
    ";
        
        $__internal_cc5d3e5676fe7d7f8d709cdc9bedbc84226ad2078736ea33fc28781cbfdcf5e2->leave($__internal_cc5d3e5676fe7d7f8d709cdc9bedbc84226ad2078736ea33fc28781cbfdcf5e2_prof);

        
        $__internal_e1da9bf180a41e6ef2cce3aa4894564a2e90ceebcc37aab0d18d3839d61f93f3->leave($__internal_e1da9bf180a41e6ef2cce3aa4894564a2e90ceebcc37aab0d18d3839d61f93f3_prof);

    }

    // line 20
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_531759a0b398bcf2a8698fd9edfe38641f217420bf22cd1d6ccb7e1e08bfe7ac = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_531759a0b398bcf2a8698fd9edfe38641f217420bf22cd1d6ccb7e1e08bfe7ac->enter($__internal_531759a0b398bcf2a8698fd9edfe38641f217420bf22cd1d6ccb7e1e08bfe7ac_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_1669f201a9a202bc2071578905315d110da9b08db0935ed4583733c889aff60d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1669f201a9a202bc2071578905315d110da9b08db0935ed4583733c889aff60d->enter($__internal_1669f201a9a202bc2071578905315d110da9b08db0935ed4583733c889aff60d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        
        $__internal_1669f201a9a202bc2071578905315d110da9b08db0935ed4583733c889aff60d->leave($__internal_1669f201a9a202bc2071578905315d110da9b08db0935ed4583733c889aff60d_prof);

        
        $__internal_531759a0b398bcf2a8698fd9edfe38641f217420bf22cd1d6ccb7e1e08bfe7ac->leave($__internal_531759a0b398bcf2a8698fd9edfe38641f217420bf22cd1d6ccb7e1e08bfe7ac_prof);

    }

    // line 21
    public function block_body($context, array $blocks = array())
    {
        $__internal_29bde9cf4ca8d7cd612730e83944965b33c6d6bb5cc9c0afc19538eaf80258a7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_29bde9cf4ca8d7cd612730e83944965b33c6d6bb5cc9c0afc19538eaf80258a7->enter($__internal_29bde9cf4ca8d7cd612730e83944965b33c6d6bb5cc9c0afc19538eaf80258a7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_879d64fea2689ebfe6140138754d37ed0ce7e197d75a404633a3218fce7a0159 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_879d64fea2689ebfe6140138754d37ed0ce7e197d75a404633a3218fce7a0159->enter($__internal_879d64fea2689ebfe6140138754d37ed0ce7e197d75a404633a3218fce7a0159_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 22
        echo "    ";
        $this->displayBlock('main', $context, $blocks);
        
        $__internal_879d64fea2689ebfe6140138754d37ed0ce7e197d75a404633a3218fce7a0159->leave($__internal_879d64fea2689ebfe6140138754d37ed0ce7e197d75a404633a3218fce7a0159_prof);

        
        $__internal_29bde9cf4ca8d7cd612730e83944965b33c6d6bb5cc9c0afc19538eaf80258a7->leave($__internal_29bde9cf4ca8d7cd612730e83944965b33c6d6bb5cc9c0afc19538eaf80258a7_prof);

    }

    public function block_main($context, array $blocks = array())
    {
        $__internal_68068ffb4e0ccfce4817fa6ffc00fee7e9fdea14a72ac5b26f8ce6aee9040284 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_68068ffb4e0ccfce4817fa6ffc00fee7e9fdea14a72ac5b26f8ce6aee9040284->enter($__internal_68068ffb4e0ccfce4817fa6ffc00fee7e9fdea14a72ac5b26f8ce6aee9040284_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_fb143ec148f722edbdd0f7c8e4c6c4a3e8841823be5da43cb15e93dddcc19897 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fb143ec148f722edbdd0f7c8e4c6c4a3e8841823be5da43cb15e93dddcc19897->enter($__internal_fb143ec148f722edbdd0f7c8e4c6c4a3e8841823be5da43cb15e93dddcc19897_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        
        $__internal_fb143ec148f722edbdd0f7c8e4c6c4a3e8841823be5da43cb15e93dddcc19897->leave($__internal_fb143ec148f722edbdd0f7c8e4c6c4a3e8841823be5da43cb15e93dddcc19897_prof);

        
        $__internal_68068ffb4e0ccfce4817fa6ffc00fee7e9fdea14a72ac5b26f8ce6aee9040284->leave($__internal_68068ffb4e0ccfce4817fa6ffc00fee7e9fdea14a72ac5b26f8ce6aee9040284_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  145 => 22,  136 => 21,  119 => 20,  107 => 15,  103 => 14,  99 => 13,  94 => 12,  85 => 11,  67 => 10,  55 => 24,  53 => 21,  49 => 20,  42 => 17,  40 => 11,  36 => 10,  30 => 6,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
   This is the base template used as the application layout which contains the
   common elements and decorates all the other templates.
   See http://symfony.com/doc/current/book/templating.html#template-inheritance-and-layouts
#}
<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <title>{% block title %}Log Noziroh{% endblock %}</title>
    {% block stylesheets %}
        <link rel=\"stylesheet\" href=\"{{ asset('css/reset.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('css/style.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('css/details-style.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('css/create-style.css') }}\">
    {% endblock %}
    <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\"/>
</head>

<body id=\"{% block body_id %}{% endblock %}\">
{% block body %}
    {% block main %}{% endblock %}
{% endblock %}
</body>
</html>
", "base.html.twig", "C:\\Users\\Ivo\\Desktop\\Soft-Tech-Exam-21\\Solutions\\PHP Skeleton\\app\\Resources\\views\\base.html.twig");
    }
}
