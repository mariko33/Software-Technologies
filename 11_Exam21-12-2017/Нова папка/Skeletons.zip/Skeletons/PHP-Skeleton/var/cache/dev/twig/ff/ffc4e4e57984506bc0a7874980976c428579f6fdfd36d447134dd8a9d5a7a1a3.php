<?php

/* report/delete.html.twig */
class __TwigTemplate_ffa076a2b55aa8d5fffca8084e05b04a05e17cc9a83469b9d6a370754bb843c4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "report/delete.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8c52b05567de5a7a9a5dfdd58c1933d96a698821ca788c00e9209328d21d927a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8c52b05567de5a7a9a5dfdd58c1933d96a698821ca788c00e9209328d21d927a->enter($__internal_8c52b05567de5a7a9a5dfdd58c1933d96a698821ca788c00e9209328d21d927a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "report/delete.html.twig"));

        $__internal_32c757b6f3c8a0d8f3af6a9c13c6e95585c0d27e7a9020eaa4752d1dc12d0598 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_32c757b6f3c8a0d8f3af6a9c13c6e95585c0d27e7a9020eaa4752d1dc12d0598->enter($__internal_32c757b6f3c8a0d8f3af6a9c13c6e95585c0d27e7a9020eaa4752d1dc12d0598_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "report/delete.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8c52b05567de5a7a9a5dfdd58c1933d96a698821ca788c00e9209328d21d927a->leave($__internal_8c52b05567de5a7a9a5dfdd58c1933d96a698821ca788c00e9209328d21d927a_prof);

        
        $__internal_32c757b6f3c8a0d8f3af6a9c13c6e95585c0d27e7a9020eaa4752d1dc12d0598->leave($__internal_32c757b6f3c8a0d8f3af6a9c13c6e95585c0d27e7a9020eaa4752d1dc12d0598_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_5a63fb9d7f3d7d3b2a06cef5c70e7bb4900909d6ca273a054f0c2983f214f354 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5a63fb9d7f3d7d3b2a06cef5c70e7bb4900909d6ca273a054f0c2983f214f354->enter($__internal_5a63fb9d7f3d7d3b2a06cef5c70e7bb4900909d6ca273a054f0c2983f214f354_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_cff013fc7204d1548e6311135c4dfa02a5d92ecf63ebe44d25a1417c4c848989 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cff013fc7204d1548e6311135c4dfa02a5d92ecf63ebe44d25a1417c4c848989->enter($__internal_cff013fc7204d1548e6311135c4dfa02a5d92ecf63ebe44d25a1417c4c848989_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "<div class=\"wrapper\">
    <form class=\"report-create\" method=\"post\">
        <div class=\"create-header\">
            Archive Report
        </div>
        <div class=\"create-status\">
            <div class=\"create-status-label\">Status</div>
            <div class=\"create-status-content\">
                <input type=\"radio\" id=\"normal-status\" name=\"report[status]\" value=\"Normal\" ";
        // line 12
        echo ((($this->getAttribute(($context["report"] ?? $this->getContext($context, "report")), "status", array()) == "Normal")) ? ("checked") : (""));
        echo " disabled/>
                <label for=\"normal-status\">Normal</label>
                <input type=\"radio\" id=\"warning-status\" name=\"report[status]\" value=\"Warning\" ";
        // line 14
        echo ((($this->getAttribute(($context["report"] ?? $this->getContext($context, "report")), "status", array()) == "Warning")) ? ("checked") : (""));
        echo " disabled/>
                <label for=\"warning-status\">Warning</label>
                <input type=\"radio\" id=\"critical-status\" name=\"report[status]\" value=\"Critical\" ";
        // line 16
        echo ((($this->getAttribute(($context["report"] ?? $this->getContext($context, "report")), "status", array()) == "Critical")) ? ("checked") : (""));
        echo " disabled/>
                <label for=\"critical-status\">Critical</label>
            </div>
        </div>
        <div class=\"create-message\">
            <div class=\"create-message-label\">Message</div>
            <textarea rows=\"3\" class=\"create-message-content\" name=\"report[message]\" disabled>";
        // line 22
        echo twig_escape_filter($this->env, $this->getAttribute(($context["report"] ?? $this->getContext($context, "report")), "message", array()), "html", null, true);
        echo "</textarea>
        </div>
        <div class=\"create-origin\">
            <div class=\"create-origin-label\">Origin</div>
            <textarea rows=\"3\" class=\"create-origin-content\" name=\"report[origin]\" disabled>";
        // line 26
        echo twig_escape_filter($this->env, $this->getAttribute(($context["report"] ?? $this->getContext($context, "report")), "origin", array()), "html", null, true);
        echo "</textarea>
        </div>
        <div class=\"create-button-holder\">
            <button type=\"submit\" class=\"submit-button\">Archive Report</button>
            <a type=\"button\" href=\"/\" class=\"back-button\">Back</a>
        </div>

        ";
        // line 33
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "_token", array()), 'row');
        echo "
    </form>
</div>
";
        
        $__internal_cff013fc7204d1548e6311135c4dfa02a5d92ecf63ebe44d25a1417c4c848989->leave($__internal_cff013fc7204d1548e6311135c4dfa02a5d92ecf63ebe44d25a1417c4c848989_prof);

        
        $__internal_5a63fb9d7f3d7d3b2a06cef5c70e7bb4900909d6ca273a054f0c2983f214f354->leave($__internal_5a63fb9d7f3d7d3b2a06cef5c70e7bb4900909d6ca273a054f0c2983f214f354_prof);

    }

    public function getTemplateName()
    {
        return "report/delete.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  95 => 33,  85 => 26,  78 => 22,  69 => 16,  64 => 14,  59 => 12,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}

{% block main %}
<div class=\"wrapper\">
    <form class=\"report-create\" method=\"post\">
        <div class=\"create-header\">
            Archive Report
        </div>
        <div class=\"create-status\">
            <div class=\"create-status-label\">Status</div>
            <div class=\"create-status-content\">
                <input type=\"radio\" id=\"normal-status\" name=\"report[status]\" value=\"Normal\" {{ report.status == 'Normal' ? 'checked' : '' }} disabled/>
                <label for=\"normal-status\">Normal</label>
                <input type=\"radio\" id=\"warning-status\" name=\"report[status]\" value=\"Warning\" {{ report.status == 'Warning' ? 'checked' : '' }} disabled/>
                <label for=\"warning-status\">Warning</label>
                <input type=\"radio\" id=\"critical-status\" name=\"report[status]\" value=\"Critical\" {{ report.status == 'Critical' ? 'checked' : '' }} disabled/>
                <label for=\"critical-status\">Critical</label>
            </div>
        </div>
        <div class=\"create-message\">
            <div class=\"create-message-label\">Message</div>
            <textarea rows=\"3\" class=\"create-message-content\" name=\"report[message]\" disabled>{{report.message}}</textarea>
        </div>
        <div class=\"create-origin\">
            <div class=\"create-origin-label\">Origin</div>
            <textarea rows=\"3\" class=\"create-origin-content\" name=\"report[origin]\" disabled>{{report.origin}}</textarea>
        </div>
        <div class=\"create-button-holder\">
            <button type=\"submit\" class=\"submit-button\">Archive Report</button>
            <a type=\"button\" href=\"/\" class=\"back-button\">Back</a>
        </div>

        {{ form_row(form._token) }}
    </form>
</div>
{% endblock %}", "report/delete.html.twig", "C:\\Users\\Ivo\\Desktop\\Soft-Tech-Exam-21\\Solutions\\PHP Skeleton\\app\\Resources\\views\\report\\delete.html.twig");
    }
}
