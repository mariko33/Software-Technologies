const mongoose = require('mongoose');

let reportSchema = mongoose.Schema({
    //TODO: Implement me ...
});

let Report = mongoose.model('Report', reportSchema);

module.exports = Report;