const Report = require('../models/Report');

module.exports = {
    index: (req, res) => {
        //TODO: Implement me ...
    },
    createGet: (req, res) => {
        //TODO: Implement me ...
    },
    createPost: (req, res) => {
        //TODO: Implement me ...
    },
    detailsGet: (req, res) => {
        //TODO: Implement me ...
    },
    deleteGet: (req, res) => {
        //TODO: Implement me ...
    },
    deletePost: (req, res) => {
        //TODO: Implement me ...
    }
};