﻿using System.ComponentModel.DataAnnotations;

namespace LogNoziroh.Models
{
    public class Report
    {
        //TODO: Implement me ...
    }
}